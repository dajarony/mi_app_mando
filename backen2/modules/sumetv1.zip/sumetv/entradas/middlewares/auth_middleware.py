"""
SUME DOCBLOCK
Nombre: Middleware de Autenticación
Tipo: Entrada

Entradas:
- Headers HTTP: Authorization Bearer <token> o X-API-KEY

Acciones:
- Extrae token de encabezados
- Valida mediante validate_token
- Exime rutas públicas y preflight CORS (OPTIONS)

Salidas:
- Permite la petición si es válido o es ruta pública/OPTIONS
- Respuesta JSON con status 401 Unauthorized si no
"""
import logging
from fastapi import Request, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import Response

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("auth_middleware")

API_KEY = "123456"

def validate_token(token: str) -> bool:
    """
    Valida el token Bearer o API key contra la constante API_KEY.
    """
    masked = ("*" * (len(token) - 4) + token[-4:]) if token and len(token) > 4 else token
    logger.info(f"Validando token: {masked}")
    return token == API_KEY

class AuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        path = request.url.path
        method = request.method.upper()
        logger.info(f"AuthMiddleware: procesando ruta {method} {path}")

        # 1) Preflight CORS: siempre permitir
        if method == "OPTIONS":
            logger.info("Preflight CORS detectado, omitiendo autenticación")
            return await call_next(request)

        # 2) Rutas públicas
        public_paths = [
            "/health", "/live", "/ready", "/metrics",
            "/docs", "/redoc", "/openapi.json"
        ]
        if any(path.startswith(p) for p in public_paths):
            logger.info(f"Ruta pública {path}: omitiendo autenticación")
            return await call_next(request)

        # 3) Extraer token de headers
        auth_header = request.headers.get("Authorization", "")
        api_key_hdr = request.headers.get("X-API-KEY", "")
        logger.info(f"Headers completos: Authorization='{auth_header}', X-API-KEY='{api_key_hdr}'")

        token = None
        if auth_header:
            if auth_header.startswith("Bearer "):
                token = auth_header.split(" ", 1)[1]
                logger.info("Token extraído de header Authorization con prefijo Bearer")
            else:
                token = auth_header
                logger.info("Token extraído de header Authorization sin prefijo Bearer")
        elif api_key_hdr:
            token = api_key_hdr
            logger.info("Token extraído de header X-API-KEY")

        if not token:
            logger.warning("No se proporcionó token de autenticación")
            # En lugar de raise HTTPException, retornamos directamente una respuesta JSON
            return JSONResponse(
                status_code=status.HTTP_401_UNAUTHORIZED,
                content={"status": "error", "message": "Unauthorized: No se proporcionó token"}
            )

        # 4) Validar token
        if not validate_token(token):
            logger.warning(f"Token de autenticación inválido: '{token}'")
            # En lugar de raise HTTPException, retornamos directamente una respuesta JSON
            return JSONResponse(
                status_code=status.HTTP_401_UNAUTHORIZED,
                content={"status": "error", "message": "Unauthorized: Token inválido"}
            )

        # 5) Si todo ok, continuar
        logger.info("Autenticación exitosa, procesando request")
        return await call_next(request)