"""
SUME DOCBLOCK

Nombre: Router TV
Tipo: Entrada

Entradas:
- POST /tv/register
- POST /tv/ping
- POST /tv/discover
- POST /tv/mirror
- POST /tv/open-app
- POST /tv/cast-url
- POST /tv/android-control
- POST /tv/list_devices
Acciones:
- Deriva a TVController
Salidas:
- JSON de resultado
"""
import logging
from fastapi import APIRouter, Request, HTTPException
from sumetv.logica.controladores.tv_controller import TVController

# Configurar logging
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("tv_router")

logger.info("Inicializando Router TV...")
# Se elimina el prefix="/tv" para evitar la duplicación de rutas
router = APIRouter(tags=["tv"])

@router.post("/register")
async def register(request: Request):
    logger.info("Recibida solicitud POST /tv/register")
    try:
        controller = TVController()
        logger.info("TVController inicializado correctamente")
        result = await controller.register(request)
        logger.info(f"Resultado de register: {result}")
        return result
    except Exception as e:
        logger.error(f"Error en register: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error interno: {str(e)}")

@router.post("/ping")
async def ping(request: Request):
    logger.info("Recibida solicitud POST /tv/ping")
    try:
        controller = TVController()
        logger.info("TVController inicializado correctamente")
        result = await controller.ping(request)
        logger.info(f"Resultado de ping: {result}")
        return result
    except Exception as e:
        logger.error(f"Error en ping: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error interno: {str(e)}")

@router.post("/discover")
async def discover(request: Request):
    logger.info("Recibida solicitud POST /tv/discover")
    try:
        controller = TVController()
        logger.info("TVController inicializado correctamente")
        result = await controller.discover(request)
        logger.info(f"Resultado de discover: {result}")
        return result
    except Exception as e:
        logger.error(f"Error en discover: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error interno: {str(e)}")

@router.post("/mirror")
async def mirror(request: Request):
    logger.info("Recibida solicitud POST /tv/mirror")
    try:
        return await TVController().mirror(request)
    except Exception as e:
        logger.error(f"Error en mirror: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error interno: {str(e)}")

@router.post("/open-app")
async def open_app(request: Request):
    logger.info("Recibida solicitud POST /tv/open-app")
    try:
        return await TVController().open_app(request)
    except Exception as e:
        logger.error(f"Error en open_app: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error interno: {str(e)}")

@router.post("/cast-url")
async def cast_url(request: Request):
    logger.info("Recibida solicitud POST /tv/cast-url")
    try:
        return await TVController().cast_url(request)
    except Exception as e:
        logger.error(f"Error en cast_url: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error interno: {str(e)}")

@router.post("/android-control")
async def android_control(request: Request):
    logger.info("Recibida solicitud POST /tv/android-control")
    try:
        controller = TVController()
        logger.info("TVController inicializado correctamente")
        result = await controller.android_control(request)
        logger.info(f"Resultado de android-control: {result}")
        return result
    except Exception as e:
        logger.error(f"Error en android-control: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error interno: {str(e)}")

@router.post("/list_devices")
async def list_devices(request: Request):
    logger.info("Recibida solicitud POST /tv/list_devices")
    try:
        controller = TVController()
        logger.info("TVController inicializado correctamente")
        result = await controller.list_devices(request)
        logger.info(f"Resultado de list_devices: {result}")
        return result
    except Exception as e:
        logger.error(f"Error en list_devices: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error interno: {str(e)}")
