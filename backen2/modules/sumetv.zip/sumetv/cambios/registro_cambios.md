## [24/04/2025] Correcciones módulo SUMETV
- Ajustes en AuthMiddleware, rutas POST, prefix "/tv"
- Controlador orquestador separado de middleware
- Servicios stub listos para implementar
