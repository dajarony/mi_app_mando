"""
SUME DOCBLOCK

Nombre: FirebaseStore
Tipo: Salida / Persistencia

Entradas:
- Objetos de modelos (TVDevice, DeviceGroup)
- IDs de dispositivos para consultas

Acciones:
- Conecta con Firebase
- Serializa/deserializa objetos
- Gestiona operaciones CRUD en Firestore

Salidas:
- Objetos recuperados/actualizados
- Estado de operaciones
"""

import os
import asyncio
import logging
import firebase_admin  # 🔥 Importación correcta agregada
from firebase_admin import credentials, firestore, initialize_app

# Configurar logging
logger = logging.getLogger("firebase_store")

# Inicializar conexión solo una vez
try:
    if not len(firebase_admin._apps):
        # MODIFICADO: Usar ruta directa a las credenciales
        cred_path = os.getenv('FIREBASE_CREDENTIALS_PATH')
        if not cred_path:
            # Usar la ruta directa a las credenciales
            cred_path = "C:/Users/gatak/Desktop/sumetv terminado.mado con multiples funcionaliades/credenciales/sumetv-94c4a-firebase.json"
            logger.info(f"Usando ruta de credenciales fija: {cred_path}")

        cred = credentials.Certificate(cred_path)
        initialize_app(cred)
        logger.info("Conexión a Firebase inicializada correctamente")
except Exception as e:
    logger.error(f"Error al inicializar Firebase: {e}")
    raise

# Instancia de Firestore
db = firestore.client()

class FirebaseStore:
    def __init__(self):
        self.devices_ref = db.collection('devices')
        logger.info("FirebaseStore inicializado, colección 'devices' lista")

    async def save_device(self, device_data: dict) -> dict:
        """
        Guardar o actualizar un dispositivo en Firestore.

        Args:
            device_data (dict): Datos del dispositivo a guardar.

        Returns:
            dict: Datos guardados.

        Raises:
            ValueError: Si device_id es vacío o nulo.
            Exception: Si hay error de conexión con Firestore.
        """
        try:
            device_id = device_data.get("device_id")
            if not device_id:
                logger.error("Intento de guardar dispositivo sin device_id")
                raise ValueError("device_id es obligatorio")

            if "registered_at" not in device_data:
                device_data["registered_at"] = firestore.SERVER_TIMESTAMP

            await asyncio.to_thread(
                self.devices_ref.document(device_id).set, device_data
            )

            logger.info(f"Dispositivo guardado correctamente: {device_id}")
            return device_data

        except Exception as e:
            logger.error(f"Error al guardar dispositivo: {e}")
            raise

    async def get_device(self, device_id: str) -> dict | None:
        """
        Obtener un dispositivo por ID.

        Args:
            device_id (str): ID del dispositivo.

        Returns:
            dict | None: Datos del dispositivo o None si no existe.

        Raises:
            Exception: Si hay error de conexión con Firestore.
        """
        try:
            doc = await asyncio.to_thread(
                self.devices_ref.document(device_id).get
            )

            if doc.exists:
                logger.info(f"Dispositivo recuperado: {device_id}")
                return doc.to_dict()

            logger.info(f"Dispositivo no encontrado: {device_id}")
            return None

        except Exception as e:
            logger.error(f"Error al obtener dispositivo {device_id}: {e}")
            raise

    async def list_devices(self) -> list:
        """
        Listar todos los dispositivos.

        Returns:
            list: Lista de dispositivos como diccionarios.

        Raises:
            Exception: Si hay error de conexión con Firestore.
        """
        try:
            # MODIFICADO: Añadido logging más detallado
            logger.info("Firebase Store: Iniciando consulta de dispositivos")
            
            devices = await asyncio.to_thread(
                lambda: list(self.devices_ref.stream())
            )

            result = [d.to_dict() for d in devices]
            logger.info(f"Recuperados {len(result)} dispositivos")
            return result

        except Exception as e:
            logger.error(f"Error al listar dispositivos: {e}")
            raise

    async def delete_device(self, device_id: str) -> bool:
        """
        Eliminar un dispositivo.

        Args:
            device_id (str): ID del dispositivo a eliminar.

        Returns:
            bool: True si se eliminó correctamente, False si no existe.

        Raises:
            Exception: Si hay error de conexión con Firestore.
        """
        try:
            doc = await asyncio.to_thread(
                self.devices_ref.document(device_id).get
            )

            if not doc.exists:
                logger.warning(f"Intento de eliminar dispositivo inexistente: {device_id}")
                return False

            await asyncio.to_thread(
                self.devices_ref.document(device_id).delete
            )

            logger.info(f"Dispositivo eliminado correctamente: {device_id}")
            return True

        except Exception as e:
            logger.error(f"Error al eliminar dispositivo {device_id}: {e}")
            raise