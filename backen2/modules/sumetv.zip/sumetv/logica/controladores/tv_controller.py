"""
SUME DOCBLOCK

Nombre: TVController
Tipo: Lógica/Controladores

Entradas:
- Request con JSON

Acciones:
- Orquesta servicios DLNA, WebRTC, ADB y Casting
- Gestiona registro y verificación de dispositivos

Salidas:
- JSON con resultado de cada operación
"""
import logging
from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse

from sumetv.entradas.descubrimiento.dlna_discovery import discover_dlna
from sumetv.logica.screenmirroring.webrtc_server import WebRTCServer
from sumetv.logica.lanzadores.mobile_app_launcher import MobileAppLauncher
from sumetv.logica.servicios.protocolos import DLNAService
from sumetv.logica.servicios.ping import ping
from sumetv.logica.servicios.android_control import send_adb_command
from sumetv.logica.Modelos.tv_device import TVDevice
from sumetv.logica.Almacen.almacen_dispositivos import (
    add_device as db_add_device,
    get_device as db_get_device,
    list_devices as db_list_devices,
)

logger = logging.getLogger("tv_controller")

class TVController:
    async def register(self, request: Request):
        """Registra o actualiza un dispositivo TV"""
        try:
            data = await request.json()
            device = TVDevice(**data)
            stored = db_add_device(device)
            return {
                "status": "success",
                "message": f"Dispositivo '{device.name}' registrado correctamente",
                "device": stored.dict(),
            }
        except Exception as e:
            logger.exception("Error al registrar dispositivo")
            raise HTTPException(status_code=400, detail=f"Formato inválido: {e}")

    async def list_devices(self, request: Request):
        """Lista todos los dispositivos registrados"""
        try:
            devices = db_list_devices()
            return {
                "status": "success",
                "devices": [d.dict() for d in devices],
            }
        except Exception as e:
            logger.exception("Error al listar dispositivos")
            raise HTTPException(status_code=500, detail="Error interno al listar dispositivos")

    async def ping(self, request: Request):
        """Verifica disponibilidad de un dispositivo por ID"""
        try:
            data = await request.json()
            device_id = data.get("device_id")
            if not device_id:
                raise HTTPException(status_code=400, detail="Falta 'device_id'")

            device = db_get_device(device_id)
            if not device:
                raise HTTPException(status_code=404, detail=f"No se encontró dispositivo con ID '{device_id}'")

            alive = await ping(device.ip)
            return {
                "status": "success",
                "device_id": device_id,
                "name": device.name,
                "alive": alive,
            }
        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Error en ping")
            raise HTTPException(status_code=500, detail="Error interno en ping")

    async def android_control(self, request: Request):
        """Envía comandos ADB a dispositivo Android TV"""
        try:
            data = await request.json()
            device_id = data.get("device_id")
            command = data.get("command")

            if not device_id or not command:
                return JSONResponse(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    content={"status": "error", "message": "Se requieren 'device_id' y 'command'"}
                )

            device = db_get_device(device_id)
            if not device:
                return JSONResponse(
                    status_code=status.HTTP_404_NOT_FOUND,
                    content={"status": "error", "message": f"No se encontró dispositivo con ID '{device_id}'"}
                )
                
            if device.type.lower() != "android":
                logger.warning(f"Intento de control Android en dispositivo no compatible: {device.name} ({device.type})")
                return JSONResponse(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    content={"status": "error", "message": f"El dispositivo '{device.name}' no es Android"}
                )

            result = await send_adb_command(device, command)
            return result
        except Exception as e:
            logger.exception(f"Error en android_control: {str(e)}")
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={"status": "error", "message": f"Error interno en android_control: {str(e)}"}
            )

    async def discover(self, request: Request):
        """Descubre dispositivos DLNA y opcionalmente los registra"""
        try:
            data = await request.json()
            timeout = data.get("timeout", 10)
            use_simulation = False
            auto_reg = data.get("auto_register", False)

            found = await discover_dlna(timeout=timeout, use_simulation=use_simulation)

            if auto_reg and found:
                for dev in found:
                    try:
                        tv = TVDevice(
                            name=dev.get("name", f"TV {dev['ip']}"),
                            ip=dev["ip"],
                            type="dlna" if dev.get("device_type") == "MediaRenderer" else "unknown",
                            location=dev.get("location"),
                            extra=dev,
                        )
                        db_add_device(tv)
                    except Exception:
                        logger.exception("Registro automático falló")

            return {"status": "success", "devices": found, "registered": auto_reg}
        except Exception as e:
            logger.exception("Error en discover")
            raise HTTPException(status_code=500, detail="Error interno en discover")

    async def mirror(self, request: Request):
        """Inicia mirroring vía WebRTC"""
        data = await request.json()
        return await WebRTCServer().start_stream(data)

    async def open_app(self, request: Request):
        """Lanza una app en el dispositivo"""
        data = await request.json()
        return MobileAppLauncher().launch_app(data.get("package"))

    async def cast_url(self, request: Request):
        """Envía URL multimedia a un dispositivo"""
        try:
            data = await request.json()
            device_id = data.get("device_id")
            url = data.get("url")

            if not device_id or not url:
                raise HTTPException(status_code=400, detail="Se requieren 'device_id' y 'url'")

            device = db_get_device(device_id)
            if not device:
                raise HTTPException(status_code=404, detail=f"Dispositivo '{device_id}' no encontrado")

            logger.info(f"Cast a {device.name} ({device.ip}): {url}")

            # Detectar tipo de contenido
            ct = "video/mp4"
            if url.endswith(".mp3"):
                ct = "audio/mpeg"
            elif url.lower().endswith((".jpg", ".jpeg")):
                ct = "image/jpeg"
            elif url.lower().endswith(".png"):
                ct = "image/png"

            if device.type == "dlna":
                try:
                    svc = DLNAService()
                    res = svc.send_content(url)
                    logger.info(f"DLNAService response: {res}")
                    return {
                        "status": "success" if "sent" in res else "error",
                        "message": res.get("sent", res.get("error", "Error DLNA")),
                        "device_id": device_id
                    }
                except Exception as ex:
                    logger.exception("Error en DLNAService.send_content")
                    raise HTTPException(status_code=500, detail=f"DLNAService fallo: {ex}")

            elif device.type == "android":
                try:
                    cmd = f'am start -a android.intent.action.VIEW -d "{url}" -t {ct}'
                    logger.info(f"Enviando intent ADB para cast-url: {cmd}")
                    out = await send_adb_command(device, cmd)
                    logger.info(f"ADB intent response: {out}")

                    # Usar el status y mensaje del resultado de send_adb_command
                    return {
                        "status": out.get("status", "error"),
                        "message": out.get("message", out.get("output", f"URL enviada a {device.name}")),
                        "device_id": device_id
                    }
                except Exception as ex:
                    logger.exception("Error enviando intent ADB para cast-url")
                    raise HTTPException(status_code=500, detail=f"Android intent fallo: {ex}")

            else:
                raise HTTPException(status_code=400, detail=f"Tipo '{device.type}' no soportado para cast")

        except HTTPException:
            raise
        except Exception as e:
            logger.exception("Error en cast_url")
            raise HTTPException(status_code=500, detail=f"Error interno en cast_url: {e}")
