""" SUME DOCBLOCK
Nombre: tv_device.py
Tipo: Lógica/Modelos

Entradas:
- Datos de dispositivos TV
Acciones:
- Define estructura de datos para TVs
Salidas:
- Modelo validado para uso en el sistema
"""
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
import uuid

class TVDevice(BaseModel):
    """Modelo de datos para dispositivos TV"""
    device_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    ip: str
    type: str  # "dlna", "android", "chromecast", etc.
    port: Optional[int] = None
    location: Optional[str] = None  # URL de descripción DLNA/UPnP
    extra: Optional[Dict[str, Any]] = None  # Metadatos adicionales