"""
SUME DOCBLOCK

Nombre: Servicios de Protocolos
Tipo: Lógica

Entradas:
- URL o payload multimedia
Acciones:
- send_content, discover
Salidas:
- Estado o error
"""
from async_upnp_client.search import async_search

class DLNAService:
    async def discover(self, timeout: int = 5):
        devices = await async_search(timeout=timeout)
        return [d for d in devices if "MediaRenderer" in d.device_type]

    def send_content(self, url: str):
        # TODO: implementar envío DLNA real
        return {"sent": url}
