"""
SUME DOCBLOCK

Nombre: almacen_dispositivos.py
Tipo: Lógica/Almacén

Entradas:
- Operaciones CRUD para dispositivos
- Importación del módulo (carga inicial de dispositivos)

Acciones:
- Almacena y sincroniza dispositivos de TV (TVDevice) en memoria y Firebase.
- Carga automáticamente los dispositivos persistidos en Firebase al iniciar el módulo.
- Proporciona operaciones CRUD tipadas para los dispositivos.

Salidas:
- Dispositivos disponibles en caché para consumo de la capa de lógica / entrada.
"""
import logging
import asyncio
import threading
import time
from typing import Dict, List, Optional, Coroutine, Any, Union

from sumetv.logica.Modelos.tv_device import TVDevice
from sumetv.salidas.firebase_store import FirebaseStore

logger = logging.getLogger("almacen_dispositivos")

# --- Utilidades ---------------------------------------------------------------------------

def _safe_run(coro: Union[Coroutine[Any, Any, Any], asyncio.Task]) -> None:
    """
    Ejecuta una corrutina de forma segura tanto dentro como fuera de un
    bucle de eventos ya existente.

    - Si hay un loop corriendo, agenda la tarea con create_task().
    - Si no, crea un nuevo loop y la ejecuta con asyncio.run().
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        # El loop ya existe → agendamos en segundo plano
        asyncio.create_task(coro)
    else:
        asyncio.run(coro)

# --- Estado interno -----------------------------------------------------------------------

devices_cache: Dict[str, TVDevice] = {}
firebase_store = FirebaseStore()

# --- Sincronización al iniciar -------------------------------------------------------------

async def _cargar_dispositivos_guardados() -> None:
    """Sincroniza la caché local con los dispositivos persistidos en Firebase."""
    try:
        dispositivos = await firebase_store.list_devices()  # type: ignore[arg-type]
        if dispositivos:
            devices_cache.clear()
            for d in dispositivos:
                try:
                    tv = TVDevice(**d)
                    devices_cache[tv.device_id] = tv
                except Exception as exc:  # pragma: no cover
                    logger.error(f"Error creando TVDevice desde Firebase: {exc!s}")

        logger.info(f"Dispositivos precargados: {len(devices_cache)}")
    except Exception as exc:  # pragma: no cover
        logger.error(f"Error precargando dispositivos: {exc!s}", exc_info=True)

_safe_run(_cargar_dispositivos_guardados())

# --- API pública ---------------------------------------------------------------------------

def add_device(device: TVDevice) -> TVDevice:
    """Registra un nuevo dispositivo o actualiza uno existente."""

    # 1. Actualizar caché
    devices_cache[device.device_id] = device

    # 2. Almacenar en Firebase en segundo plano
    async def _persist() -> None:
        data = device.dict() if hasattr(device, "dict") else {
            k: v for k, v in device.__dict__.items() if not k.startswith("_")
        }
        data = {k: v for k, v in data.items() if v is not None}

        try:
            await firebase_store.save_device(data)
            logger.info("Dispositivo guardado en Firebase: %s (%s)", device.name, device.device_id)
        except Exception as exc:  # pragma: no cover
            logger.error(f"Error guardando dispositivo en Firebase: {exc!s}")

    _safe_run(_persist())
    return device


def get_device(device_id: str) -> Optional[TVDevice]:
    """Recupera un dispositivo por su *device_id*."""

    # 1. Buscar en caché primero
    if device_id in devices_cache:
        return devices_cache[device_id]

    # 2. Si no está, consultar Firebase en segundo plano
    async def _fetch() -> None:
        try:
            data = await firebase_store.get_device(device_id)
            if data:
                tv = TVDevice(**data)
                devices_cache[device_id] = tv
        except Exception as exc:  # pragma: no cover
            logger.error(f"Error recuperando dispositivo {device_id} desde Firebase: {exc!s}")

    _safe_run(_fetch())
    # Devolvemos lo que haya (puede ser None si aún no se completó)
    return devices_cache.get(device_id)


def list_devices() -> List[TVDevice]:
    """Devuelve la lista de dispositivos sincronizados (caché en RAM)."""

    # Lanzamos sincronización paralela si la caché está vacía para no bloquear.
    if not devices_cache:
        async def _refresh() -> None:
            try:
                dispositivos = await firebase_store.list_devices()
                if dispositivos:
                    devices_cache.clear()
                    for d in dispositivos:
                        try:
                            tv = TVDevice(**d)
                            devices_cache[tv.device_id] = tv
                        except Exception as exc:
                            logger.error(f"Error creando TVDevice: {exc!s}")
            except Exception as exc:
                logger.error(f"Error refrescando dispositivos: {exc!s}")

        _safe_run(_refresh())

    return list(devices_cache.values())


def remove_device(device_id: str) -> bool:
    """Elimina un dispositivo tanto de la caché como de Firebase."""

    removed = devices_cache.pop(device_id, None) is not None

    async def _delete() -> None:
        try:
            await firebase_store.delete_device(device_id)
            logger.info("Dispositivo eliminado de Firebase: %s", device_id)
        except Exception as exc:
            logger.error(f"Error eliminando dispositivo de Firebase: {exc!s}")

    _safe_run(_delete())
    return removed
